<?php
/**
 * Options for the yixue plugin
 *
 * @author Goldentianya <goldentianya@gmail.com>
 */

$lang['urlkatex'] = 'load katex.js  library. (when using Katex)';
$lang['urlautorender'] = 'load auto-render.js  library.(when using Katex)';
$lang['urlcss'] = 'load katex css  file.(when using Katex)';
$lang['urlyixue'] = 'load yixue library.';
$lang['usekatex'] = 'Use Katex（otherweis use MathJax）';
