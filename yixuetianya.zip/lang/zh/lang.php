<?php
/**
 * English language file for dwtimeline plugin
 *
 * @author saggi <saggi@gmx.de>
 */

// menu entry for admin plugins
// $lang['menu'] = 'Your menu entry';

// custom language strings for the plugin
$lang['tl-button'] = 'Insert Timeline skeleton';

