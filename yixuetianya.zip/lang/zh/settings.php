<?php
/**
 * Options for the yixue plugin
 *
 * @author Goldentianya <goldentianya@gmail.com>
 */

$lang['urlkatex'] = '载入 katex.js  库文件地址。(选用Katex时生效)';
$lang['urlautorender'] = '载入 auto-render.js  库文件地址。(选用Katex时生效)';
$lang['urlcss'] = '载入 katex css  模式文件地址。(选用Katex时生效)';
$lang['urlyixue'] = '载入易学库文件地址。';
$lang['usekatex'] = '使用 Katex 库（不勾选则使用MathJax）';
