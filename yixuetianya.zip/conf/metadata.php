<?php
/**
 * Options for the yixue plugin
 *
 * @author Goldentianya <goldentianya@gmail.com>
 */

$meta['urlkatex'] = array('string');
$meta['urlautorender'] = array('string');
$meta['urlcss'] = array('string');
$meta['urlyixue'] = array('string');
$meta['usekatex'] = array('onoff');
